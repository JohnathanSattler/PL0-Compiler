// Compiler Builder 8
// Lester Young
// Timothy Konzel
// Remington Howell
// Johnathan Sattler
// John Herold

// Included libraries
#include <stdio.h>
#include <stdlib.h>
#include "input.h"
#include "lexer.h"
#include "printing.h"
#include "tokens.h"
#include "parser.h"